interface JwtPayload {
    id: number;
    nome: string;
    role: string;
  }
  
   declare namespace Express {
      export interface Request {
        user?: JwtPayload;
      }
    }
