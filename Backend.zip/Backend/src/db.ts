import mysql from 'mysql2/promise';
import dotenv from 'dotenv';
dotenv.config();

export const pool = mysql.createPool({
//  host: process.env.localhost,
 // user: process.env.root,
 // password: process.env.toor,
//  database: process.env.my1stbook,
});
