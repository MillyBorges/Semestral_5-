import { pool } from '../db';

export interface Leitura {
  id_leitura?: number;
  id_cliente: number;
  id_livro: number;
  paginas_lidas: number;
  data_leitura?: Date;
}

export interface PontuacaoCliente {
  nivel: number;
  pontos: number;
  totalPaginas: number;
}

export async function registrarLeitura(leitura: Leitura): Promise<{ pontuacao: PontuacaoCliente }> {
  // Iniciar transação para garantir integridade de registro e atualização
  const conn: any = await pool.getConnection();

  try {
    await conn.query('START TRANSACTION');

    // 1. Insere leitura e pontua páginas
    const sql = 'INSERT INTO leitura (id_cliente, id_livro, paginas_lidas, data_leitura) VALUES (?, ?, ?, NOW())';
    await conn.execute(sql, [leitura.id_cliente, leitura.id_livro, leitura.paginas_lidas]);

    // 2. Soma total de páginas lidas do cliente
    const [rows]: any = await conn.query(
      'SELECT SUM(paginas_lidas) as total_paginas FROM leitura WHERE id_cliente = ?',
      [leitura.id_cliente]
    );
    const totalPaginas = rows[0]?.total_paginas || 0;

    // 3. Calcula nível e pontos novos
    const nivel = Math.floor(totalPaginas / 10); // 1 nível a cada 10 páginas lidas
    const pontos = totalPaginas; // 1 ponto por página, ou ajuste sua regra

    // 4. Atualiza cliente
    await conn.execute(
      'UPDATE Clientes SET nivel = ?, pontos = ? WHERE id_cliente = ?',
      [nivel, pontos, leitura.id_cliente]
    );

    // Finaliza transação
    await conn.query('COMMIT');

    return {
      pontuacao: { nivel, pontos, totalPaginas }
    };
  } catch (error) {
    await conn.query('ROLLBACK');
    throw error;
  } finally {
    conn.release();
  }
}

export async function getNivelCliente(id_cliente: number): Promise<PontuacaoCliente> {
  const [rows]: any = await pool.query(
    'SELECT nivel, pontos FROM Clientes WHERE id_cliente = ?',
    [id_cliente]
  );
  // Retornar nível, pontos e totalPaginas para informar bem o usuário
  const [totalRows]: any = await pool.query(
    'SELECT SUM(paginas_lidas) as total_paginas FROM leitura WHERE id_cliente = ?',
    [id_cliente]
  );
  return {
    nivel: rows[0]?.nivel || 0,
    pontos: rows[0]?.pontos || 0,
    totalPaginas: totalRows[0]?.total_paginas || 0
  };
}
