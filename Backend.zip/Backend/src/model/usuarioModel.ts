import { connectionModel } from "./connectionModels";
import { User } from "../interfaces/types";
import { hashPassword } from "../services/passwordService";
import { RowDataPacket } from "mysql2";

const getUserAll = async () => {
    const [listUsuario] = await connectionModel.execute('SELECT * FROM usuario')
    return listUsuario
}

const getByUserId = async (id: number) => {
    const [user] = await connectionModel.execute(`SELECT * FROM usuario where id=${id}`)
    return user
}

export const EmailUsers = async (email: string | undefined) =>{    

        const query = 'SELECT * FROM usuario WHERE email = ? LIMIT 1';      
        // rows será um array de RowDataPacket
        const [rows] = await connectionModel.execute(query, [email]);
        console.log('Model ', rows )
        return rows;
    
}

export const findByEmail = async (email: string | undefined): Promise<User | null> => {
    const query = 'SELECT * FROM usuario WHERE email = ?';
  
    const [rows] = await connectionModel.execute<RowDataPacket[]>(query, [email]);
    console.log('model ', rows[0])
    return rows[0] as User  || null; 
};

const createNewUser = async (body: User) => {
    const { nome, email, password, endereco, telefone, idade, preferencia_categorias, nivel, role, createdAt } = body
    const hashP = await hashPassword(password)
    console.log(hashP)
    const query = 'INSERT INTO usuario(nome,email,password, endereco, telefone, idade, preferencia_categorias, nivel, role ,createdAt ) values(?,?,?,?,?,?,?,?,?,?)'
    const [newUser] = await connectionModel.execute(query, [nome, email, hashP, endereco, telefone, idade, preferencia_categorias, nivel, role, createdAt ?? new Date()])
    return newUser
}

const editUserPartial = async (id: number, updates: Partial<User>) => {

    if (!updates.createdAt) {
        updates.createdAt = new Date()
    }
    const fields = Object.keys(updates);
    const values = Object.values(updates);
    const setclause = fields.map(field => `${field} = ?`).join(', ')
    const query = `UPDATE usuario set ${setclause}, updatedAt = NOW() where id= ?`
    const [result] = await connectionModel.execute(query, [...values, id])
    return result
}
const removeUser = async (id: number) => {
    const [user] = await connectionModel.execute(`DELETE FROM usuario where id= ${id}`)
    return user
}

export default {
    getUserAll,
    getByUserId,
    findByEmail,
    createNewUser,
    editUserPartial,
    removeUser,
    EmailUsers
}

