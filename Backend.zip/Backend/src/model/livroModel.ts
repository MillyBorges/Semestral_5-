import { connectionModel } from "../model/connectionModels";
import type { Product } from '../interfaces/types';
import { hashPassword } from "../services/passwordService";

const getBookAll =  async () =>{
    const [listProducts] = await connectionModel.execute('SELECT * FROM livros')
    return listProducts
}

const getByBookId =  async (id:number) =>{
    const [product] = await connectionModel.execute(`SELECT * FROM livros where id_livro=${id}`)
    return product
}
const createNewBook = async (body: Product) => {
    const {
      titulo = null,
      autor = null,
      categoria = null,
      ano_publicacao = null,
      isbn = null,
      preco = null,
      quantidade_estoque = null,
      descricao = null,
      imagem_url = null,
      previa = null,
      classificacao_indicativa = null,
      totalPaginas = null,
      createdAt = new Date(),
      updatedAt = new Date(),
    } = body;
  
    const query = `INSERT INTO livros(
      titulo, autor, categoria, ano_publicacao, isbn,
      preco, quantidade_estoque, descricao, imagem_url, previa,
      classificacao_indicativa, totalPaginas, createdAt, updatedAt
    ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`;
  
    const params = [
      titulo,
      autor,
      categoria,
      ano_publicacao,
      isbn,
      preco,
      quantidade_estoque,
      descricao,
      imagem_url,
      previa,
      classificacao_indicativa,
      totalPaginas,
      createdAt,
      updatedAt,
    ];
  
    const [newProduct] = await connectionModel.execute(query, params);
    return newProduct;
  };
const editBook =  async (id:number, body:Product) =>{
    const {titulo,autor,categoria,ano_publicacao, isbn, preco, quantidade_estoque, descricao, imagem_url, previa, classificacao_indicativa, totalPaginas, createdAt,updatedAt} = body
    const query = 'UPDATE livros set titulo=?,autor=?,categoria=?,ano_publicacao=?, isbn=?, preco=?, quantidade_estoque=?, descricao=?, imagem_url=?, previa=?, classificacao_indicativa=?, totalPaginas=?,updatedAt=? where id = ?'
    const [productEdit] = await connectionModel.execute(query,[titulo,autor,categoria,ano_publicacao, isbn, preco, quantidade_estoque, descricao, imagem_url, previa, classificacao_indicativa, totalPaginas, createdAt,updatedAt?? new Date(),id])
    return productEdit
}

const editBookPartial = async (id:number,updates:Partial<Product>)=>{
    delete updates.createdAt;
    if(!updates.updatedAt){
        updates.updatedAt = new Date()
    }

    const fields = Object.keys(updates);
    const values =  Object.values(updates);
    const setclause =  fields.map(field => `${field} = ?`).join(', ')
    const query = `UPDATE livros set ${setclause}, updatedAt = NOW() where id_livro= ?`
    const [result] = await connectionModel.execute(query,[...values,id])
    return result
}
const removeBook =  async (id:number) =>{
  console.log("model ",id)
    const [product] = await connectionModel.execute("DELETE FROM livros WHERE id_livro = ?", [id]);
    return product
}

export default {
    getBookAll,
    getByBookId,
    createNewBook,
    editBook,
    editBookPartial,
    removeBook
}

