import { pool } from '../db';

export interface RankingItem {
  id_cliente: number;
  nome: string;
  pontos: number;
  nivel: number;
  total_paginas: number;
}

// Lista os top clientes por pontos
export async function getRankingTop(limit: number = 10): Promise<RankingItem[]> {
  const [rows]: any = await pool.query(
    `SELECT c.id_cliente, c.nome, c.pontos, c.nivel,
      COALESCE(SUM(l.paginas_lidas), 0) as total_paginas
     FROM Clientes c
     LEFT JOIN leitura l ON l.id_cliente = c.id_cliente
     GROUP BY c.id_cliente, c.nome, c.pontos, c.nivel
     ORDER BY c.pontos DESC, c.nivel DESC
     LIMIT ?`,
    [limit]
  );
  return rows as RankingItem[];
}

// Retorna a posição de um cliente no ranking por pontos
export async function getRankingPosicao(id_cliente: number): Promise<number> {
  const [rows]: any = await pool.query(
    `SELECT id_cliente FROM Clientes ORDER BY pontos DESC, nivel DESC`
  );
  const pos = rows.findIndex((item: any) => item.id_cliente === id_cliente);
  return pos >= 0 ? pos + 1 : -1;
}
