import { pool } from '../db';

export interface Troca {
  id_troca?: number;
  id_cliente: number;
  id_livro: number;
  pontos_gastos: number;
  data_troca?: Date;
}

// Realiza a troca de pontos por livro
export async function fazerTroca(troca: Troca): Promise<{ sucesso: boolean; saldoRestante?: number; mensagem?: string }> {
  const conn: any = await pool.getConnection();

  try {
    await conn.query('START TRANSACTION');

    // Verifica saldo de pontos do cliente
    const [clienteRows]: any = await conn.query('SELECT pontos FROM Clientes WHERE id_cliente = ?', [troca.id_cliente]);
    if (clienteRows.length === 0) {
      await conn.query('ROLLBACK');
      return { sucesso: false, mensagem: 'Cliente não encontrado' };
    }

    const pontosAtual = clienteRows[0].pontos;
    if (pontosAtual < troca.pontos_gastos) {
      await conn.query('ROLLBACK');
      return { sucesso: false, mensagem: 'Pontos insuficientes para a troca' };
    }

    // Deduz pontos do cliente
    await conn.execute('UPDATE Clientes SET pontos = pontos - ? WHERE id_cliente = ?', [troca.pontos_gastos, troca.id_cliente]);

    // Registra a troca
    const sql = 'INSERT INTO trocas (id_cliente, id_livro, pontos_gastos, data_troca) VALUES (?, ?, ?, NOW())';
    await conn.execute(sql, [troca.id_cliente, troca.id_livro, troca.pontos_gastos]);

    await conn.query('COMMIT');

    return { sucesso: true, saldoRestante: pontosAtual - troca.pontos_gastos };
  } catch (error) {
    await conn.query('ROLLBACK');
    throw error;
  } finally {
    conn.release();
  }
}
