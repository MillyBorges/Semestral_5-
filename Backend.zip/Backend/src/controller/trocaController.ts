// trocaController.ts
import { Request, Response } from 'express';
import { fazerTroca, Troca } from '../model/trocaModel';

export const TrocaController = {
  // POST /troca/fazer
  async realizarTroca(req: Request, res: Response) {
    try {
      const troca: Troca = req.body;

      if (!troca.id_cliente || !troca.id_livro || !troca.pontos_gastos) {
        return res.status(400).json({ error: 'Campos obrigatórios faltando.' });
      }

      const resultado = await fazerTroca(troca);

      if (!resultado.sucesso) {
        return res.status(400).json({ error: resultado.mensagem || 'Falha na troca de pontos.' });
      }

      return res.status(201).json({
        mensagem: 'Troca realizada com sucesso',
        saldoRestante: resultado.saldoRestante
      });
    } catch (error: any) {
      return res.status(500).json({
        error: 'Erro ao processar a troca',
        details: error.message || error
      });
    }
  }
};
