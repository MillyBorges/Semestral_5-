import type { User } from "../interfaces/types";
import userModel from "../model/usuarioModel";
import type { Request, Response } from "express";


const getUsertAll = async (req: Request, res: Response) => {
    const listUser = await userModel.getUserAll()
    try {
        if (!listUser) {
            return res.status(400).json({ message: "Dados não encontrado" })
        }
        return res.status(200).json(listUser)

    } catch (error) {
        console.error("Erro ao buscar usuario:", error); // Log do erro para o dev
        return res.status(500).json({ message: "Erro interno no servidor." });
    };
}

const getByUserId = async (req: Request, res: Response) => {
    try {
        const id= Number(req.params.id);
           const user = await userModel.getByUserId(id)
        if (!user) {
            return res.status(404).json({ message: 'Dados não encontrados' })
        }
        return res.status(200).json(user)

    } catch (error) {
        console.error("Erro ao criar usuario:", error);
        return res.status(500).json({ message: "Erro interno no servidor." });
    }
}

const getByEmailUser = async (req: Request, res: Response) => {
   
    try {
        const user = await userModel.EmailUsers(req.params.email)

        if (!user) {
            return res.status(404).json({ message: 'Dados não encontrados' })
        }
       
        return res.status(200).json(user)

    } catch (error) {
        console.error("Erro ao criar usuario:", error);
        return res.status(500).json({ message: "Erro interno no servidor." });
    }
}

const createNewUser = async (req: Request, res: Response): Promise<Response> => {

    console.log('aquiiiiiiiiiiiiiiii ', req.body)
    try {
        const newUser = await userModel.createNewUser(req.body)
        return res.status(201).json(newUser)

    } catch (error) {
        console.error("Erro ao criar usuario:", error);
        return res.status(500).json({ message: "Erro interno no servidor." });

    }

}

const editUserPartial = async (req: Request, res: Response) => {
    const id = Number(req.params.id)
    const updates: Partial<User> = req.body
    const result = await userModel.editUserPartial(id, updates)
    return res.status(200).json(result)
}
const removeUser = async (req: Request, res: Response) => {
    const user = await userModel.removeUser(Number(req.params.id))
    return res.status(204)
}

export default {
    getUsertAll,
    getByUserId,
    getByEmailUser,
    createNewUser,
    editUserPartial,
    removeUser
}
