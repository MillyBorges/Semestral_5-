import { Request, Response } from "express"
import usuarioModel from "../model/usuarioModel"
import jwtServices from '../services/jwtService'
import { comparePassword } from '../services/passwordService'
import livroController from "./livroController"
import livroModel from "../model/livroModel"
import jwt from 'jsonwebtoken';

interface IData {
    id: number;
    nome: string;
    role: string;
}
const loginUser = async (req: Request, res: Response) => {
    const { email, password } = req.body
    try {
        const user = await usuarioModel.findByEmail(email)
   
        if (!user) return res.status(404).json({ message: 'Usuario não encontrado' })
        const validarSenha = await comparePassword(password, user.password)
   
        if (!validarSenha) return res.status(404).json({ message: 'Senha ou password não conferem' })
    
            const data: IData = {
            id: user.id,
            nome: user.nome,
            role: user.role
        }

        
        const token = jwtServices.sign(data)
        return res.status(200).json({ token })
        
    } catch (error) {
        console.error("Erro no login:", error);
        return res.status(500).json({ message: "Erro interno no servidor." });

    }

}
const createNewBook = async (req: Request, res: Response) => {
    try {
  
        const newProduct = await livroModel.createNewBook(req.body)
        return res.status(201).json(newProduct)
  
    } catch (error) {
        console.error("Erro ao criar produto:", error);
        return res.status(500).json({ message: "Erro interno no servidor." });
  
    }
  
}


export default {
    loginUser,
    createNewBook
}

