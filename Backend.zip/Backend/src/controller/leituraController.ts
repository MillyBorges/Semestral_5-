// leituraController.ts
import { Request, Response } from 'express';
import { registrarLeitura, getNivelCliente, Leitura } from '../model/leituraModel';

export const LeituraController = {
  // POST /leitura/registrar
  async registrar(req: Request, res: Response) {
    try {
      const leitura: Leitura = req.body;
      if (!leitura.id_cliente || !leitura.id_livro || !leitura.paginas_lidas) {
        return res.status(400).json({ error: 'Dados obrigatórios faltando.' });
      }

      const { pontuacao } = await registrarLeitura(leitura);

      return res.status(201).json({
        mensagem: 'Leitura registrada com sucesso',
        pontuacao
      });
    } catch (error: any) {
      return res.status(500).json({
        error: 'Erro ao registrar leitura',
        details: error.message || error
      });
    }
  },

  // GET /leitura/nivel/:id_cliente
  async getNivel(req: Request, res: Response) {
    try {
      const id_cliente = Number(req.params.id_cliente);
      if (!id_cliente) {
        return res.status(400).json({ error: 'ID do cliente é obrigatório' });
      }

      const pontuacao = await getNivelCliente(id_cliente);
      return res.json({ pontuacao });
    } catch (error: any) {
      return res.status(500).json({
        error: 'Erro ao buscar pontuação/nivel',
        details: error.message || error
      });
    }
  }
};
