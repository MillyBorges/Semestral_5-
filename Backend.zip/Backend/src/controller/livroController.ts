import { Request, Response } from 'express';
import { pool } from '../db';
import livroModel from '../model/livroModel';
import { Livro } from '../interfaces/types';


export async function addLivro(req: Request, res: Response) {
  try {
    await livroModel.createNewBook(req.body);
    res.status(201).json({ message: 'Livro adicionado com sucesso!' });
  } catch (error) {
    console.error(error);
    res.status(500).json({ error: 'Erro ao adicionar livro.' });
  }
}


export async function listarLivros(req: Request, res: Response) {
  try {
    const { classificacao_indicativa, categoria, min_paginas } = req.query;

    let query = 'SELECT * FROM livros WHERE 1=1';
    const params: Array<string | number> = [];

    if (classificacao_indicativa) {
      query += ' AND classificacao_indicativa = ?';
      params.push(String(classificacao_indicativa));
    }

    if (categoria) {
      query += ' AND id_categoria = (SELECT id_categoria FROM categorias WHERE nome_categoria = ?)';
      params.push(String(categoria));
    }

    if (min_paginas) {
      query += ' AND totalPaginas >= ?';
      params.push(Number(min_paginas));
    }

    query += ' ORDER BY titulo ASC';

    const [rows] = await pool.query(query, params);
    res.json(rows);
  } catch (error) {
    console.error('Erro ao listar livros:', error);
    res.status(500).json({ error: 'Erro ao listar livros' });
  }
}


const getBookAll = async (req: Request, res: Response) => {

  const listProducts = await livroModel.getBookAll()
  try {
      if (!listProducts) {
          return res.status(400).json({ message: "Dados não encontrado" })
      }
      return res.status(200).json(listProducts)

  } catch (error) {
      console.error("Erro ao buscar produtos:", error); // Log do erro para o dev
      return res.status(500).json({ message: "Erro interno no servidor." });
  };


}

const getByBookId = async (req: Request, res: Response) => {
  try {
      const id= Number(req.params.id);
         const product = await livroModel.getByBookId(id)
      if (!product) {
          return res.status(404).json({ message: 'Dados não encontrado' })
      }
      return res.status(200).json(product)

  } catch (error) {
      console.error("Erro ao criar produto:", error);
      return res.status(500).json({ message: "Erro interno no servidor." });
  }


}

const createNewBook = async (req: Request, res: Response) => {
  try {

      const newProduct = await livroModel.createNewBook(req.body)
      return res.status(201).json(newProduct)

  } catch (error) {
      console.error("Erro ao criar produto:", error);
      return res.status(500).json({ message: "Erro interno no servidor." });

  }

}
const editBook = async (req: Request, res: Response) => {
  const id = Number(req.params.id)
  const productEdit = await livroModel.editBook(id, req.body)
  return res.status(200).json(productEdit)
}

const editBookPartial = async (req: Request, res: Response) => {
  const id = Number(req.params.id)
  const updates: Partial<Livro> = req.body
  const result = await livroModel.editBookPartial(id, updates)
  return res.status(200).json(result)
}
const removeBook = async (req: Request, res: Response) => {
  const product = await livroModel.removeBook(Number(req.params.id))
  return res.status(204).json({"message":"Produto deletatdo com sucesso"})
}

export default {
  addLivro,
  getBookAll,
  getByBookId,
  createNewBook,
  editBook,
  editBookPartial,
  removeBook
}
