
import { Request, Response } from 'express';
import { getRankingTop, getRankingPosicao } from '../model/rankingModel';

export const RankingController = {
  async listarTop(req: Request, res: Response) {
    try {
      const limit = Number(req.query.limit) || 10;
      const ranking = await getRankingTop(limit);
      return res.json({ ranking });
    } catch (error: any) {
      return res.status(500).json({
        error: 'Erro ao buscar ranking',
        details: error.message || error
      });
    }
  },


  async posicaoCliente(req: Request, res: Response) {
    try {
      const id_cliente = Number(req.params.id_cliente);
      if (!id_cliente) {
        return res.status(400).json({ error: 'ID do cliente é obrigatório' });
      }
      const posicao = await getRankingPosicao(id_cliente);
      if (posicao === -1) {
        return res.status(404).json({ error: 'Cliente não encontrado no ranking' });
      }
      return res.json({ posicao });
    } catch (error: any) {
      return res.status(500).json({
        error: 'Erro ao buscar posição no ranking',
        details: error.message || error
      });
    }
  }
};
