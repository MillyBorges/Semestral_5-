import express from 'express';
import usuarioController from '../controller/usuarioController';
import { authenticate, authorize } from '../middlewares/authMiddleware';

export const usuarioRoutes = express.Router();

usuarioRoutes.post('/', usuarioController.createNewUser);

// usuarioRoutes.use(authenticate);
// usuarioRoutes.use(authorize);
usuarioRoutes.get('/:email', usuarioController.getByEmailUser);
usuarioRoutes.get('/', usuarioController.getUsertAll);
usuarioRoutes.get('/:id', usuarioController.getByUserId);

usuarioRoutes.patch('/:id', usuarioController.editUserPartial);
usuarioRoutes.delete('/:id', usuarioController.removeUser);
