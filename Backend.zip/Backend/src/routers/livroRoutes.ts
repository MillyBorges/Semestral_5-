import express from 'express'
import livroController from '../controller/livroController';
//import { validate } from '../middlewares/validateRequest'
//import { createProductSchema } from '../schemas/productSchema'
import { authenticate, authorize } from '../middlewares/authMiddleware'
import { Router } from 'express';

import multer from 'multer';

const upload = multer({ dest: 'uploads/' });
const router = Router();

export const livroRoutes =  express.Router()
livroRoutes.get('/catalogo', livroController.getBookAll)
livroRoutes.get('/:id', livroController.getByBookId)
livroRoutes.post('/novoLivro', authenticate,authorize(['admin']), livroController.addLivro)
livroRoutes.patch('/:id', authenticate,authorize(['admin']), livroController.editBookPartial)
livroRoutes.put('/:id', authenticate,authorize(['admin']),livroController.editBook)
livroRoutes.delete('/:id', authenticate,authorize(['admin']),livroController.removeBook)


export default router;
