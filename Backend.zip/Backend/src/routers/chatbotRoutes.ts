import express from 'express'
import chatbotController from '../controller/chatbotController'

export const chatrouter = express.Router()
chatrouter.post('/chat', chatbotController.handler)