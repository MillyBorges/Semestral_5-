// trocaRouter.ts
import { Router } from 'express';
import { TrocaController } from '../controller/trocaController';

const router = Router();

router.post('/fazer', TrocaController.realizarTroca);

export default router;
