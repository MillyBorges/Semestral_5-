// leituraRouter.ts
import { Router } from 'express';
import { LeituraController } from '../controller/leituraController';

const router = Router();

router.post('/registrar', LeituraController.registrar);
router.get('/nivel/:id_cliente', LeituraController.getNivel);

export default router;
