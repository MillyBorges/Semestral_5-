// rankingRouter.ts
import { Router } from 'express';
import { RankingController } from '../controller/rankingController';

const router = Router();

router.get('/top', RankingController.listarTop);
router.get('/posicao/:id_cliente', RankingController.posicaoCliente);

export default router;
