import express from 'express'
import authController from '../controller/authController'

export const routerAuth = express.Router()

routerAuth.post('/', authController.loginUser)

