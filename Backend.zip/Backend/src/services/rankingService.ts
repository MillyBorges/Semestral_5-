import { pool } from '../db';

export async function getRanking(): Promise<Array<{id_cliente: number, nome: string, nivel: number}>> {
  const [rows]: any = await pool.query('SELECT id_cliente, nome, nivel FROM Clientes ORDER BY nivel DESC LIMIT 10');
  return rows;
}
