import axios from 'axios';

export async function validarTrocaML(pontos: number, idade: number, categoriaFavorita: string) {
  const response = await axios.post('http://localhost:8000/validar-troca', {
    pontos,
    idade,
    categoria_favorita: categoriaFavorita
  });
  return response.data;
}
