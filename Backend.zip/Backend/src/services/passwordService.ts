import bcrypt from 'bcrypt'
import { config } from 'dotenv'
config()

const saltRounds = Number(process.env.SALTROUNDS) || 10;

export const hashPassword = async (password: string) => {
    if (!password) throw new Error("Password inválido");
    console.log(password)
    return await bcrypt.hash(password, saltRounds);
};

export const comparePassword = async (password: string, hash: string) => {
    if (!password || !hash) throw new Error("Dados inválidos para comparação");
    return await bcrypt.compare(password, hash);
};