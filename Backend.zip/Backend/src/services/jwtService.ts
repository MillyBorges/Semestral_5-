// Cole isto no seu arquivo: services/jwtService.ts

import jwt from 'jsonwebtoken'
import { config } from 'dotenv'
import { IJwtPayload } from '../interfaces/types'; // Verifique se este caminho está correto

config()

// Garante que a variável de ambiente existe ao iniciar
if (!process.env.JWTSECRET) {
  throw new Error('Variável de ambiente JWTSECRET não foi definida.');
}
const JWT_SECRET = process.env.JWTSECRET;

/**
 * Cria um novo token JWT.
 */
const sign = (data: IJwtPayload ): string => {
    return jwt.sign(data, JWT_SECRET, { expiresIn: '1h' })
}

/**
 * Verifica um token JWT.
 * Deixa o erro original da biblioteca 'jsonwebtoken' ser lançado
 * para que o middleware 'authenticate' possa capturá-lo.
 */
const verify = (token: string): IJwtPayload  => {
  // O try...catch foi removido daqui
  const decoded = jwt.verify(token, JWT_SECRET);
  
  // Se o payload decodificado for uma string, é um formato inesperado.
  if (typeof decoded === 'string') {
    throw new Error('Payload do token é inválido (string).');
  }

  return decoded as IJwtPayload ;
};

export default {
    sign,
    verify
}