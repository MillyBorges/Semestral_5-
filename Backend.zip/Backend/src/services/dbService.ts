//import { clienteModel } from '../model/clienteModel';
//import { Livro } from '../model/livroModel';
import mysql, { RowDataPacket } from 'mysql2/promise';

const pool = mysql.createPool({
  host: 'localhost',
  user: 'root',
  password: 'toor',
  database: 'my1stbook',
});

interface Cliente {
  idade: number;
  pontos: number;
  preferencia_categorias: string;
}

interface Livro {
  nome_categoria: string;
}

export async function getDadosTroca(idCliente: number, idLivro: number) {
  const [clienteRows] = await pool.query<RowDataPacket[] & Cliente[]>(
    'SELECT idade, pontos, preferencia_categorias FROM Clientes JOIN Pontuacao_Clientes USING (id_cliente) WHERE id_cliente = ?',
    [idCliente]
  );

  const [livroRows] = await pool.query<RowDataPacket[] & Livro[]>(
    'SELECT nome_categoria FROM Livros JOIN Categorias ON Livros.id_categoria = Categorias.id_categoria WHERE id_livro = ?',
    [idLivro]
  );

  return {
    pontos: clienteRows[0]?.pontos,
    idade: clienteRows[0]?.idade,
    categoriaFavorita: livroRows[0]?.nome_categoria,
  };
}