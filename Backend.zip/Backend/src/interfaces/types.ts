import { RowDataPacket } from "mysql2";

export interface Livro {
    id: number;
    titulo: string;
    autor: string;
    descricao?: string;
    ano: number;
    preco: number;
  }


export interface User extends RowDataPacket {
  id: number;
  email: string;
  password: string; // O hash do bcrypt
  name: string;
  endereco: string;
  telefone: string;
  idade: number;
  preferencia_categoria: string;
  nivel: number;
  role: string;
  createdAt: Date;
}

export interface Product {
  id: number;
  titulo: string;
  autor: string;
  categoria: string;
  ano_publicacao: Date;
  isbn: string;
  preco: number;
  quantidade_estoque: number;
  descricao?: string;
  imagem_url: string;
  previa: string;
  classificacao_indicativa: string;
  totalPaginas: number;
  createdAt: Date;
  updatedAt: Date;
}

export interface Order {
  id:number;
  userId:number;
  createdAt: Date;
  totalAmount:number;
}

export interface OrderItem {
  id: number;
  orderId: number;
  productId:number;
  quantity:number;
  price:number;

}

export interface IJwtPayload {
  id: number;
  nome: string;
  role: string;
}