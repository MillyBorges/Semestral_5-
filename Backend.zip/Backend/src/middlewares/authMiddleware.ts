import jwtServices from "../services/jwtService";
import type { Request, Response, NextFunction } from "express";

export const authenticate = (req: Request, res: Response, next: NextFunction): void => {
  const authHeader = req.header("Authorization");

  if (!authHeader?.startsWith("Bearer ")) {
    res.status(401).json({ message: "Token não fornecido ou mal formatado" });
    return;
  }

  const token = authHeader.split(" ")[1];
  if (!token) {
    res.status(401).json({ message: "Token ausente após 'Bearer'" });
    return;
  }

  try {
    const decodedPayload = jwtServices.verify(token);
    console.log("Payload decodificado do JWT:", decodedPayload);

    (req as any).user = decodedPayload;
    next();
  } catch (error: any) {
    console.error("Falha na verificação do token:", error.message);
    res.status(401).json({
      message: "Token inválido ou expirado",
      error: error.message,
    });
  }
};
export const authorize = (roles: string[]) => {
  return (req: Request, res: Response, next: NextFunction): void => {
    const user = (req as any).user;

    if (!user?.role) {
      res.status(403).json({ message: "Usuário não autenticado ou sem papel (role) definido." });
      return;
    }

    if (!roles.includes(user.role)) {
      res.status(403).json({ message: "Permissão negada: acesso restrito." });
      return;
    }

    next();
  };
};
