import express from 'express';
import cors from 'cors';

import { livroRoutes } from './routers/livroRoutes';
import { usuarioRoutes } from './routers/usuarioRoutes';
import leituraRoutes from './routers/leituraRoutes';
import rankingRoutes from './routers/rankingRoutes';
import { setupSwagger } from './middlewares/swagger';
import { routerAuth } from './routers/routerAuth';
import { chatrouter } from './routers/chatbotRoutes'; 

const app = express();

app.use(cors({
    origin: "*",
    methods: ["GET", "POST", "PUT", "DELETE", "PATCH"], 
    allowedHeaders: ["Content-Type", "Authorization"]
}));
app.use(express.json());

app.use('/api/livros', livroRoutes);
app.use('/api/usuario', usuarioRoutes);
app.use('/api', leituraRoutes);
app.use('/api/ranking', rankingRoutes);
app.use('/api', chatrouter);
app.use('/api/login', routerAuth);


setupSwagger(app);

export default app;
