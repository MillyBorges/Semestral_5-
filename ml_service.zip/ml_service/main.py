from fastapi import FastAPI
from pydantic import BaseModel
import joblib
import pandas as pd

app = FastAPI()

class TrocaRequest(BaseModel):
    pontos: int
    idade: int
    categoria_favorita: str

model = joblib.load("modelo_troca.pkl")
encoder = joblib.load("encoder_cat.pkl")

@app.post("/validar-troca")
def validar_troca(request: TrocaRequest):
    cat_enc = encoder.transform([[request.categoria_favorita]]).toarray()
    input_data = pd.DataFrame([[request.pontos, request.idade]], columns=['pontos', 'idade'])
    input_data = pd.concat([input_data, pd.DataFrame(cat_enc, columns=encoder.get_feature_names_out())], axis=1)
    pred = model.predict(input_data)[0]
    autorizado = bool(pred == 1)
    mensagem = "Troca autorizada." if autorizado else "Troca negada pelo modelo."
    return {"autorizado": autorizado, "mensagem": mensagem}
